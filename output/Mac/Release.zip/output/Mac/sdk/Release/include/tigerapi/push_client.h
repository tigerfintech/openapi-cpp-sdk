﻿#ifndef PUSH_CLIENT_H
#define PUSH_CLIENT_H
#include <memory>
#include <functional>
#include "tigerapi/win32.h"
#include "tigerapi/model.h"
#include "tigerapi/client_config.h"
#include "tigerapi/enums.h"
#include "openapi_pb/pb_source/Request.pb.h"
#include "openapi_pb/pb_source/Response.pb.h"
#include "openapi_pb/pb_source/SocketCommon.pb.h"
#include "openapi_pb/pb_source/PushData.pb.h"
#include "openapi_pb/pb_source/AssetData.pb.h"
#include "openapi_pb/pb_source/PositionData.pb.h"
#include "openapi_pb/pb_source/OrderStatusData.pb.h"
#include "openapi_pb/pb_source/OrderTransactionData.pb.h"
#include "openapi_pb/pb_source/QuoteData.pb.h"
#include "openapi_pb/pb_source/QuoteBasicData.pb.h"
#include "openapi_pb/pb_source/QuoteBBOData.pb.h"
#include "openapi_pb/pb_source/KlineData.pb.h"
#include "openapi_pb/pb_source/TickData.pb.h"
#include "openapi_pb/pb_source/TradeTickData.pb.h"
#include "openapi_pb/pb_source/StockTopData.pb.h"
#include "openapi_pb/pb_source/OptionTopData.pb.h"
#include "openapi_pb/pb_source/QuoteDepthData.pb.h"

namespace TIGER_API
{
	class ClientConfig;
	class OPENAPI_EXPORT IPushClient
	{
	public:
		static std::shared_ptr<IPushClient> create_push_client(const TIGER_API::ClientConfig& client_config);
		virtual const ClientConfig& get_client_config() const = 0;

		virtual void connect() = 0;
		virtual void disconnect() = 0;

		virtual void set_connected_callback(const std::function<void()>& cb) = 0;
		virtual void set_disconnected_callback(const std::function<void()>& cb) = 0;
		virtual void set_inner_error_callback(const std::function<void(std::string)>& cb) = 0;

		virtual void set_subscribe_callback(const std::function<void(const tigeropen::push::pb::Response&)>& cb) = 0;
		virtual void set_unsubscribe_callback(const std::function<void(const tigeropen::push::pb::Response&)>& cb) = 0;
		virtual void set_error_callback(const std::function<void(const tigeropen::push::pb::Response&)>& cb) = 0;
		virtual void set_kickout_callback(const std::function<void(const tigeropen::push::pb::Response&)>& cb) = 0;
		
		virtual void set_asset_changed_callback(const std::function<void(const tigeropen::push::pb::AssetData&)>& cb) = 0;
		virtual unsigned int subscribe_asset(const std::string& account) = 0;
		virtual unsigned int unsubscribe_asset(const std::string& account) = 0;
		
		virtual void set_position_changed_callback(const std::function<void(const tigeropen::push::pb::PositionData&)>& cb) = 0;
		virtual unsigned int subscribe_position(const std::string& account) = 0;
		virtual unsigned int unsubscribe_position(const std::string& account) = 0;

		virtual void set_order_changed_callback(const std::function<void(const tigeropen::push::pb::OrderStatusData&)>& cb) = 0;
		virtual unsigned int subscribe_order(const std::string& account) = 0;
		virtual unsigned int unsubscribe_order(const std::string& account) = 0;

		virtual void set_transaction_changed_callback(const std::function<void(const tigeropen::push::pb::OrderTransactionData&)>& cb) = 0;
		virtual unsigned int subscribe_transaction(const std::string& account) = 0;
		virtual unsigned int unsubscribe_transaction(const std::string& account) = 0;
		
		virtual void set_query_subscribed_symbols_changed_callback(const std::function<void(const tigeropen::push::pb::Response& query_subscribed_symbols_response)>& cb) = 0;
		virtual unsigned int query_subscribed_symbols() = 0;
		
		virtual void set_quote_changed_callback(const std::function<void(const tigeropen::push::pb::QuoteBasicData&)>& cb) = 0;
		virtual void set_quote_bbo_changed_callback(const std::function<void(const tigeropen::push::pb::QuoteBBOData&)>& cb) = 0;
		virtual unsigned int subscribe_quote(const std::vector<std::string>& symbols) = 0;
		virtual unsigned int subscribe_future_quote(const std::vector<std::string>& symbols) = 0;
		virtual unsigned int subscribe_option_quote(const std::vector<std::string>& symbols) = 0;
		virtual unsigned int unsubscribe_quote(const std::vector<std::string>& symbols) = 0;

		virtual void set_quote_depth_changed_callback(const std::function<void(const tigeropen::push::pb::QuoteDepthData&)>& cb) = 0;
		virtual unsigned int subscribe_quote_depth(const std::vector<std::string>& symbols) = 0;
		virtual unsigned int unsubscribe_quote_depth(const std::vector<std::string>& symbols) = 0;

		virtual void set_kline_changed_callback(const std::function<void(const tigeropen::push::pb::KlineData&)>& cb) = 0;
		virtual unsigned int subscribe_kline(const std::vector<std::string>& symbols) = 0;
		virtual unsigned int unsubscribe_kline(const std::vector<std::string>& symbols) = 0;

		virtual void set_full_tick_changed_callback(const std::function<void(const tigeropen::push::pb::TickData&)>& cb) = 0;
		virtual void set_tick_changed_callback(const std::function<void(const TradeTick&)>& cb) = 0;
		virtual unsigned int subscribe_tick(const std::vector<std::string>& symbols) = 0;
		virtual unsigned int unsubscribe_tick(const std::vector<std::string>& symbols) = 0;

		virtual unsigned int subscribe_market(const std::string& market) = 0;
		virtual unsigned int unsubscribe_market(const std::string& market) = 0;

		virtual void set_stock_top_changed_callback(const std::function<void(const tigeropen::push::pb::StockTopData&)>& cb) = 0;
		virtual unsigned int subscribe_stock_top(const std::string& market) = 0;
		virtual unsigned int unsubscribe_stock_top(const std::string& market) = 0;

		virtual void set_option_top_changed_callback(const std::function<void(const tigeropen::push::pb::OptionTopData&)>& cb) = 0;
		virtual unsigned int subscribe_option_top(const std::string& market) = 0;
		virtual unsigned int unsubscribe_option_top(const std::string& market) = 0;

	};
}

#endif // PUSH_CLIENT_H

