﻿//
// Created by sukai on 2022/12/27.
//

#ifndef TIGERAPI_MODEL_H
#define TIGERAPI_MODEL_H

#include <typeinfo>
//#include <any>
#include <string>
#include "cpprest/json.h"
#include "cpprest/details/basic_types.h"
#include "win32.h"

using namespace std;

namespace TIGER_API {

    class OPENAPI_EXPORT Contract {
    public:
        Contract() {};

        Contract(const utility::string_t sec_type, const utility::string_t symbol, const utility::string_t currency,
                 const utility::string_t local_symbol,
                 const utility::string_t exchange, long contract_id) : sec_type(sec_type), symbol(symbol),
                                                                       currency(currency),
                                                                       local_symbol(local_symbol), exchange(exchange),
                                                                       contract_id(contract_id) {};

        Contract(const utility::string_t sec_type, const utility::string_t symbol, const utility::string_t expiry,
                 const utility::string_t strike, const utility::string_t right,
                 const utility::string_t currency, long multiplier, const utility::string_t local_symbol,
                 long contract_id) :
                sec_type(sec_type), symbol(symbol), expiry(expiry), strike(strike), right(right),
                currency(currency), multiplier(multiplier), local_symbol(local_symbol), contract_id(contract_id) {};

        Contract(const utility::string_t sec_type, const utility::string_t symbol, const utility::string_t expiry,
                 long multiplier,
                 const utility::string_t contract_month,
                 const utility::string_t currency, const utility::string_t exchange,
                 const utility::string_t local_symbol) :
                sec_type(sec_type), symbol(symbol), expiry(expiry), currency(currency), multiplier(multiplier),
                exchange(exchange), contract_month(contract_month), local_symbol(local_symbol) {};

        utility::string_t symbol;
        utility::string_t currency;
        utility::string_t sec_type;
        utility::string_t exchange;
        utility::string_t local_symbol;
        utility::string_t expiry;
        utility::string_t strike;
        utility::string_t right;
        int multiplier = 0;
        utility::string_t contract_month;
        long contract_id = 0;
        utility::string_t identifier;
        utility::string_t market;
    };

    /** One leg of a multi-leg (combo) order, e.g. an option spread. **/
    class OPENAPI_EXPORT ContractLeg {
    public:
        ContractLeg() {};

        ContractLeg(const utility::string_t sec_type, const utility::string_t symbol,
                    const utility::string_t action, int ratio) :
                sec_type(sec_type), symbol(symbol), action(action), ratio(ratio) {};

        ContractLeg(const utility::string_t sec_type, const utility::string_t symbol,
                    const utility::string_t strike, const utility::string_t expiry, const utility::string_t right,
                    const utility::string_t action, int ratio) :
                sec_type(sec_type), symbol(symbol), strike(strike), expiry(expiry), right(right),
                action(action), ratio(ratio) {};

        utility::string_t symbol;
        utility::string_t sec_type;
        utility::string_t expiry;
        utility::string_t strike;
        utility::string_t right;
        /** trade direction for this leg, 'BUY' / 'SELL' **/
        utility::string_t action;
        /** relative weight of this leg in the combo, must be greater than 0 **/
        int ratio = 0;

        web::json::value to_json() const {
            web::json::value obj = web::json::value::object(true);
            if (!symbol.empty()) obj[U("symbol")] = web::json::value::string(symbol);
            if (!sec_type.empty()) obj[U("sec_type")] = web::json::value::string(sec_type);
            if (!expiry.empty()) obj[U("expiry")] = web::json::value::string(expiry);
            if (!strike.empty()) obj[U("strike")] = web::json::value::string(strike);
            if (!right.empty()) obj[U("right")] = web::json::value::string(right);
            if (!action.empty()) obj[U("action")] = web::json::value::string(action);
            if (ratio != 0) obj[U("ratio")] = web::json::value::number(ratio);
            return obj;
        }
    };

    /** A single tag/value pair used for algo order parameters (e.g. TWAP/VWAP start_time). **/
    class OPENAPI_EXPORT AlgoParam {
    public:
        AlgoParam() {};

        AlgoParam(const utility::string_t tag, const utility::string_t value) : tag(tag), value(value) {};

        utility::string_t tag;
        utility::string_t value;

        web::json::value to_json() const {
            web::json::value obj = web::json::value::object(true);
            obj[U("tag")] = web::json::value::string(tag);
            obj[U("value")] = web::json::value::string(value);
            return obj;
        }
    };

    class OPENAPI_EXPORT Order {
    public:
        Order() {};

        Order(const utility::string_t order_type, const utility::string_t account, Contract &contract,
              const utility::string_t action, long long total_quantity) :
                order_type(order_type), account(account), contract(contract), action(action),
                total_quantity(total_quantity) {};

        Order(const utility::string_t order_type, const utility::string_t account, Contract &contract,
              const utility::string_t action, long long total_quantity,
              double limit_price, double aux_price = 0, double trailing_percent = 0) :
                order_type(order_type), account(account), contract(contract), action(action),
                total_quantity(total_quantity),
                limit_price(limit_price), aux_price(aux_price), trailing_percent(trailing_percent) {};

        Contract contract;
        utility::string_t account;
        unsigned long long id = 0;
        long order_id = 0;
        /** order type, 'MKT' market order / 'LMT' limit order / 'STP' stop order / 'STP_LMT' stop limit order / 'TRAIL' trailing stop order **/
        utility::string_t order_type;   
        /** trade direction, 'BUY' / 'SELL' **/
        utility::string_t action;
        /** order quantity **/
        long long total_quantity = 0;
        /** order quantity scale, if total_quantity is 5, total_quantity_scale is 1, then the actual order quantity is 5 * 10^-1 = 0.5 **/
        long total_quantity_scale = 0;
        /** limit price **/
        double limit_price = 0;
        utility::string_t s_limit_price;
        /** in stop order, it represents the price to trigger the stop order, in trailing stop order, it represents the price to track **/
        double aux_price = 0;
        double trail_stop_price = 0;
        double trailing_percent = 0;
        double percent_offset = 0;
        /** expiration time, 'DAY' day order / 'GTC' good till cancel  / 'GTD' good till date **/
        utility::string_t time_in_force;
        /** allow pre-market and post-market trading (US market exclusive). True allow, False not allow **/
        bool outside_rth;
        /**
            * price adjustment range (default 0 means no adjustment, positive means upward adjustment, negative means downward adjustment), automatically adjust the input price to a legal price.
            * For example: 0.001 means upward adjustment and the adjustment range is not more than 0.1%; -0.001 means downward adjustment and the adjustment range is not more than 0.1%. Default 0 means no adjustment
         */
        double adjust_limit = 0.0;
        utility::string_t user_mark;
        time_t expire_time = 0;

        // order status
        utility::string_t status;
        // parent order id, currently only used for TigerTrade App's additional order
        unsigned long long parent_id;
        // order time
        time_t open_time;
        // order failed, return the description of the failure reason
        utility::string_t reason;
        // latest transaction time
        time_t latest_time;
        // order updated time
        time_t update_time;
        // filled quantity
        long long filled_quantity;
        // filled quantity scale
        long filled_quantity_scale;
        // average fill price including commission
        double avg_fill_price;
        // realized profit and loss
        double realized_pnl;
        utility::string_t secret_key;
        web::json::value sub_ids;
        utility::string_t algo_strategy;
        double commission;
        double gst;
        // iceberg order fields
        long long display_size = 0;
        long long min_display_size = 0;
        long long check_intervals = 0;
        utility::string_t price_type;
        long long start_time = 0;
        long long end_time = 0;

        // algo order fields (TWAP/VWAP/WAP); algo_strategy (e.g. "TWAP"/"VWAP") is declared above
        vector<AlgoParam> algo_params;
        void add_algo_param(const utility::string_t& tag, const utility::string_t& value) {
            if (tag.empty() || value.empty()) return;
            algo_params.push_back(AlgoParam(tag, value));
        }

        // amount order: order by cash amount instead of quantity (e.g. fund subscription)
        double cash_amount = 0;

        // multi-leg (combo) order fields
        /** combo strategy type: COVERED/PROTECTIVE/VERTICAL/STRADDLE/STRANGLE/CALENDAR/DIAGONAL/SYNTHETIC/CUSTOM **/
        utility::string_t combo_type;
        vector<ContractLeg> contract_legs;

        // OCA (one-cancels-all) bracket order: a set of sibling orders where one fill cancels the rest
        vector<Order> oca_orders;

        // attached order fields (profit-taker / stop-loss / brackets)
        /** attached order type: 'PROFIT' / 'LOSS' / 'BRACKETS' **/
        utility::string_t attach_type;
        long profit_taker_order_id = 0;
        double profit_taker_price = 0;
        utility::string_t profit_taker_tif;
        bool profit_taker_rth = false;
        /** stop-loss order type, e.g. 'STP' / 'STP_LMT' / 'TRAIL' **/
        utility::string_t stop_loss_order_type;
        long stop_loss_order_id = 0;
        double stop_loss_price = 0;
        double stop_loss_limit_price = 0;
        utility::string_t stop_loss_tif;
        double stop_loss_trailing_percent = 0;
        double stop_loss_trailing_amount = 0;

        utility::string_t to_string() {
            utility::stringstream_t ss;
            ss << U("Order(id=") << this->id << U(" status=") << this->status << U(" total_quantity: ")
               << this->total_quantity
               << U(" limit_price: ") << this->limit_price << ")" << endl;
            return ss.str();
        };

        Order(const web::json::value &json) {
            if (json.has_field(U("id"))) {
                id = json.at(U("id")).as_number().to_uint64();
            }
            if (json.has_field(U("orderType"))) {
                order_type = json.at(U("orderType")).as_string();
            }
            if (json.has_field(U("account"))) {
                account = json.at(U("account")).as_string();
            }
            if (json.has_field(U("symbol"))) {
                utility::string_t symbol = json.at(U("symbol")).as_string();
                utility::string_t sec_type = json.at(U("secType")).as_string();
                utility::string_t market = json.at(U("market")).as_string();
                utility::string_t currency = json.at(U("currency")).as_string();
                contract = Contract();
                contract.symbol = symbol;
                contract.sec_type = sec_type;
                contract.market = market;
                contract.currency = currency;
            }
            if (json.has_field(U("action"))) {
                action = json.at(U("action")).as_string();
            }
            if (json.has_field(U("limitPrice"))) {
                limit_price = json.at(U("limitPrice")).as_double();
            }
            if (json.has_field(U("auxPrice"))) {
                aux_price = json.at(U("auxPrice")).as_double();
            }
            if (json.has_field(U("trailingPercent"))) {
                trailing_percent = json.at(U("trailingPercent")).as_double();
            }
            if (json.has_field(U("timeInForce"))) {
                time_in_force = json.at(U("timeInForce")).as_string();
            }
            if (json.has_field(U("outsideRth"))) {
                outside_rth = json.at(U("outsideRth")).as_bool();
            }
            if (json.has_field(U("adjustLimit"))) {
                adjust_limit = json.at(U("adjustLimit")).as_double();
            }
            if (json.has_field(U("userMark"))) {
                user_mark = json.at(U("userMark")).as_string();
            }
            if (json.has_field(U("expireTime"))) {
                expire_time = json.at(U("expireTime")).as_number().to_int64();
            }
            if (json.has_field(U("status"))) {
                status = json.at(U("status")).as_string();
            }
            if (json.has_field(U("parentId"))) {
                parent_id = json.at(U("parentId")).as_number().to_uint64();
            }
            if (json.has_field(U("openTime"))) {
                open_time = json.at(U("openTime")).as_number().to_int64();
            }
            if (json.has_field(U("reason"))) {
                reason = json.at(U("reason")).as_string();
            }
            if (json.has_field(U("latestTime"))) {
                latest_time = json.at(U("latestTime")).as_number().to_int64();
            }
            if (json.has_field(U("updateTime"))) {
                update_time = json.at(U("updateTime")).as_number().to_int64();
            }
            if (json.has_field(U("filledQuantity"))) {
                filled_quantity = json.at(U("filledQuantity")).as_number().to_int64();
            }
            if (json.has_field(U("totalQuantity"))) {
                total_quantity = json.at(U("totalQuantity")).as_number().to_int64();
            }
            if (json.has_field(U("avgFillPrice"))) {
                avg_fill_price = json.at(U("avgFillPrice")).as_double();
            }
            if (json.has_field(U("realizedPnl"))) {
                realized_pnl = json.at(U("realizedPnl")).as_double();
            }
            if (json.has_field(U("commission"))) {
                commission = json.at(U("commission")).as_double();
            }
            if (json.has_field(U("gst"))) {
                gst = json.at(U("gst")).as_double();
            }
            if (json.has_field(U("subIds"))) {
                sub_ids = json.at(U("subIds"));
            }
            if (json.has_field(U("algoStrategy"))) {
                algo_strategy = json.at(U("algoStrategy")).as_string();
            }
            if (json.has_field(U("algoParams")) && json.at(U("algoParams")).is_array()) {
                for (const auto& param_json : json.at(U("algoParams")).as_array()) {
                    AlgoParam param;
                    if (param_json.has_field(U("tag"))) param.tag = param_json.at(U("tag")).as_string();
                    if (param_json.has_field(U("value"))) param.value = param_json.at(U("value")).as_string();
                    algo_params.push_back(param);
                }
            }
            if (json.has_field(U("displaySize"))) {
                display_size = json.at(U("displaySize")).as_number().to_int64();
            }
            if (json.has_field(U("minDisplaySize"))) {
                min_display_size = json.at(U("minDisplaySize")).as_number().to_int64();
            }
            if (json.has_field(U("checkIntervals"))) {
                check_intervals = json.at(U("checkIntervals")).as_number().to_int64();
            }
            if (json.has_field(U("priceType"))) {
                price_type = json.at(U("priceType")).as_string();
            }
            if (json.has_field(U("startTime"))) {
                start_time = json.at(U("startTime")).as_number().to_int64();
            }
            if (json.has_field(U("endTime"))) {
                end_time = json.at(U("endTime")).as_number().to_int64();
            }
            if (json.has_field(U("totalQuantityScale"))) {
                total_quantity_scale = json.at(U("totalQuantityScale")).as_number().to_int64();
            }
            if (json.has_field(U("filledQuantityScale"))) {
                filled_quantity_scale = json.at(U("filledQuantityScale")).as_number().to_int64();
            }
            if (json.has_field(U("secret_key"))) {
                secret_key = json.at(U("secret_key")).as_string();
            }
            if (json.has_field(U("cashAmount"))) {
                cash_amount = json.at(U("cashAmount")).as_double();
            }
            if (json.has_field(U("comboType"))) {
                combo_type = json.at(U("comboType")).as_string();
            }
            if (json.has_field(U("contractLegs")) && json.at(U("contractLegs")).is_array()) {
                for (const auto& leg_json : json.at(U("contractLegs")).as_array()) {
                    ContractLeg leg;
                    if (leg_json.has_field(U("symbol"))) leg.symbol = leg_json.at(U("symbol")).as_string();
                    if (leg_json.has_field(U("secType"))) leg.sec_type = leg_json.at(U("secType")).as_string();
                    if (leg_json.has_field(U("expiry"))) leg.expiry = leg_json.at(U("expiry")).as_string();
                    if (leg_json.has_field(U("strike"))) leg.strike = leg_json.at(U("strike")).as_string();
                    if (leg_json.has_field(U("right"))) leg.right = leg_json.at(U("right")).as_string();
                    if (leg_json.has_field(U("action"))) leg.action = leg_json.at(U("action")).as_string();
                    if (leg_json.has_field(U("ratio"))) leg.ratio = leg_json.at(U("ratio")).as_integer();
                    contract_legs.push_back(leg);
                }
            }
            if (json.has_field(U("ocaOrders")) && json.at(U("ocaOrders")).is_array()) {
                for (const auto& oca_json : json.at(U("ocaOrders")).as_array()) {
                    oca_orders.push_back(Order(oca_json));
                }
            }
            if (json.has_field(U("attachType"))) {
                attach_type = json.at(U("attachType")).as_string();
            }
            if (json.has_field(U("profitTakerOrderId"))) {
                profit_taker_order_id = (long) json.at(U("profitTakerOrderId")).as_number().to_int64();
            }
            if (json.has_field(U("profitTakerPrice"))) {
                profit_taker_price = json.at(U("profitTakerPrice")).as_double();
            }
            if (json.has_field(U("profitTakerTif"))) {
                profit_taker_tif = json.at(U("profitTakerTif")).as_string();
            }
            if (json.has_field(U("profitTakerRth"))) {
                profit_taker_rth = json.at(U("profitTakerRth")).as_bool();
            }
            if (json.has_field(U("stopLossOrderType"))) {
                stop_loss_order_type = json.at(U("stopLossOrderType")).as_string();
            }
            if (json.has_field(U("stopLossOrderId"))) {
                stop_loss_order_id = (long) json.at(U("stopLossOrderId")).as_number().to_int64();
            }
            if (json.has_field(U("stopLossPrice"))) {
                stop_loss_price = json.at(U("stopLossPrice")).as_double();
            }
            if (json.has_field(U("stopLossLimitPrice"))) {
                stop_loss_limit_price = json.at(U("stopLossLimitPrice")).as_double();
            }
            if (json.has_field(U("stopLossTif"))) {
                stop_loss_tif = json.at(U("stopLossTif")).as_string();
            }
            if (json.has_field(U("stopLossTrailingPercent"))) {
                stop_loss_trailing_percent = json.at(U("stopLossTrailingPercent")).as_double();
            }
            if (json.has_field(U("stopLossTrailingAmount"))) {
                stop_loss_trailing_amount = json.at(U("stopLossTrailingAmount")).as_double();
            }

        };

    };

    class OPENAPI_EXPORT Position {
    public:
        Position() {};

        Position(const utility::string_t &account, const Contract &contract, long long position = 0,
                 double average_cost = 0.0,
                 double latest_price = 0.0, double market_value = 0.0, double realized_pnl = 0.0,
                 double unrealized_pnl = 0.0)
                : account(account), contract(contract), position(position), average_cost(average_cost),
                  latest_price(latest_price), market_value(market_value), realized_pnl(realized_pnl),
                  unrealized_pnl(unrealized_pnl) {};

        Position(const web::json::value &json) {
            if (json.has_field(U("account"))) {
                account = json.at(U("account")).as_string();
            }
            if (json.has_field(U("symbol"))) {
                utility::string_t symbol = json.at(U("symbol")).as_string();
                utility::string_t sec_type = json.at(U("secType")).as_string();
                utility::string_t market = json.at(U("market")).as_string();
                utility::string_t currency = json.at(U("currency")).as_string();
                utility::string_t identifier = json.at(U("identifier")).as_string();
                long contract_id = json.at(U("contractId")).as_integer();
                long multiplier = (long) json.at(U("multiplier")).as_number().to_uint64();
                contract = Contract();
                contract.symbol = symbol;
                contract.sec_type = sec_type;
                contract.market = market;
                contract.currency = currency;
                contract.contract_id = contract_id;
                contract.identifier = identifier;
                contract.multiplier = multiplier;
            }
            if (json.has_field(U("position"))) {
                position = json.at(U("position")).as_number().to_uint64();
            }
            if (json.has_field(U("averageCost"))) {
                average_cost = json.at(U("averageCost")).as_double();
            }
            if (json.has_field(U("marketValue"))) {
                market_value = json.at(U("marketValue")).as_double();
            }
            if (json.has_field(U("realizedPnl"))) {
                realized_pnl = json.at(U("realizedPnl")).as_double();
            }
            if (json.has_field(U("unrealizedPnl"))) {
                unrealized_pnl = json.at(U("unrealizedPnl")).as_double();
            }
            if (json.has_field(U("latestPrice"))) {
                latest_price = json.at(U("latestPrice")).as_double();
            }
            if (json.has_field(U("updateTimestamp"))) {
                update_timestamp = json.at(U("updateTimestamp")).as_number().to_uint64();
            }
            if (json.has_field(U("status"))) {
                status = json.at(U("status")).as_integer();
            }
        }

        utility::string_t account;
        Contract contract;
        long long position;
        double average_cost;
        double market_value;
        double realized_pnl;
        double unrealized_pnl;
        double latest_price;
        int status;
        time_t update_timestamp;


        utility::string_t to_string() {
            utility::stringstream_t ss;
            ss << U("Position(symbol=") << this->contract.symbol << U(" position=") << this->position << ")" << endl;
            return ss.str();
        };
    };

    class OPENAPI_EXPORT CurrencyAsset {
    public:
        CurrencyAsset() {};

        CurrencyAsset(const web::json::value &json) {
            if (json.has_field(U("cashAvailableForTrade"))) {
                this->cash_available_for_trade = json.at(U("cashAvailableForTrade")).as_double();
            }
            if (json.has_field(U("cashBalance"))) {
                this->cash_balance = json.at(U("cashBalance")).as_double();
            }
            if (json.has_field(U("currency"))) {
                this->currency = json.at(U("currency")).as_string();
            }
            if (json.has_field(U("grossPositionValue"))) {
                this->gross_position_value = json.at(U("grossPositionValue")).as_double();
            }
            if (json.has_field(U("optionMarketValue"))) {
                this->option_market_value = json.at(U("optionMarketValue")).as_double();
            }
            if (json.has_field(U("realizedPL"))) {
                this->realized_pl = json.at(U("realizedPL")).as_double();
            }
            if (json.has_field(U("stockMarketValue"))) {
                this->stock_market_value = json.at(U("stockMarketValue")).as_double();
            }
            if (json.has_field(U("unrealizedPL"))) {
                this->unrealized_pl = json.at(U("unrealizedPL")).as_double();
            }
        }


        double cash_available_for_trade = 0;
        double cash_balance = 0;
        utility::string_t currency;
        double gross_position_value = 0;
        double option_market_value = 0;
        double realized_pl = 0;
        double stock_market_value = 0;
        double unrealized_pl = 0;
    };

    class OPENAPI_EXPORT Segment {
    public:
        Segment() {};

        Segment(const web::json::value &segment_json) {
            if (segment_json.has_field(U("buyingPower"))) {
                this->buying_power = segment_json.at(U("buyingPower")).as_double();
            }
            if (segment_json.has_field(U("capability"))) {
                this->capability = segment_json.at(U("capability")).as_string();
            }
            if (segment_json.has_field(U("cashAvailableForTrade"))) {
                this->cash_available_for_trade = segment_json.at(U("cashAvailableForTrade")).as_double();
            }
            if (segment_json.has_field(U("cashAvailableForWithdrawal"))) {
                this->cash_available_for_withdrawal = segment_json.at(U("cashAvailableForWithdrawal")).as_double();
            }
            if (segment_json.has_field(U("cashBalance"))) {
                this->cash_balance = segment_json.at(U("cashBalance")).as_double();
            }
            if (segment_json.has_field(U("category"))) {
                this->category = segment_json.at(U("category")).as_string();
            }
            if (segment_json.has_field(U("currency"))) {
                this->currency = segment_json.at(U("currency")).as_string();
            }
            if (segment_json.has_field(U("equityWithLoan"))) {
                this->equity_with_loan = segment_json.at(U("equityWithLoan")).as_double();
            }
            if (segment_json.has_field(U("excessLiquidation"))) {
                this->excess_liquidation = segment_json.at(U("excessLiquidation")).as_double();
            }
            if (segment_json.has_field(U("grossPositionValue"))) {
                this->gross_position_value = segment_json.at(U("grossPositionValue")).as_double();
            }
            if (segment_json.has_field(U("initMargin"))) {
                this->init_margin = segment_json.at(U("initMargin")).as_double();
            }
            if (segment_json.has_field(U("leverage"))) {
                this->leverage = segment_json.at(U("leverage")).as_double();
            }
            if (segment_json.has_field(U("lockedFunds"))) {
                this->locked_funds = segment_json.at(U("lockedFunds")).as_double();
            }
            if (segment_json.has_field(U("maintainMargin"))) {
                this->maintain_margin = segment_json.at(U("maintainMargin")).as_double();
            }
            if (segment_json.has_field(U("netLiquidation"))) {
                net_liquidation = segment_json.at(U("netLiquidation")).as_double();
            }
            if (segment_json.has_field(U("overnightLiquidation"))) {
                overnight_liquidation = segment_json.at(U("overnightLiquidation")).as_double();
            }
            if (segment_json.has_field(U("overnightMargin"))) {
                overnight_margin = segment_json.at(U("overnightMargin")).as_double();
            }
            if (segment_json.has_field(U("realizedPL"))) {
                realized_pl = segment_json.at(U("realizedPL")).as_double();
            }
            if (segment_json.has_field(U("totalTodayPL"))) {
                total_today_pl = segment_json.at(U("totalTodayPL")).as_double();
            }
            if (segment_json.has_field(U("unrealizedPL"))) {
                unrealized_pl = segment_json.at(U("unrealizedPL")).as_double();
            }
            if (segment_json.has_field(U("unrealizedPLByCostOfCarry"))) {
                unrealized_plby_cost_of_carry = segment_json.at(U("unrealizedPLByCostOfCarry")).as_double();
            }
        };

        utility::string_t category;
        utility::string_t capability;
        utility::string_t currency;
        double buying_power = 0;
        double cash_available_for_trade = 0;
        double cash_available_for_withdrawal = 0;
        double cash_balance = 0;
        double equity_with_loan = 0;
        double excess_liquidation = 0;
        double gross_position_value = 0;
        double init_margin = 0;
        double leverage = 0;
        double locked_funds = 0;
        double maintain_margin = 0;
        double net_liquidation = 0;
        double overnight_liquidation = 0;
        double overnight_margin = 0;
        double realized_pl = 0;
        double total_today_pl = 0;
        double unrealized_pl = 0;
        double unrealized_plby_cost_of_carry = 0;
        vector<CurrencyAsset> currency_assets;

        utility::string_t to_string() {
            utility::stringstream_t ss;
            ss << U("Segment(category=") << this->category << U(" currency=") << this->currency << ")" << endl;
            return ss.str();
        };

    };

    class OPENAPI_EXPORT PortfolioAccount {
    public:
        PortfolioAccount() {};
        utility::string_t account;
        long update_timestamp;
        vector<Segment> segments;

        utility::string_t to_string() {
            utility::stringstream_t ss;
            ss << U("PortfolioAccount(account=") << this->account << U(" update_timestamp=") << this->update_timestamp
               << ")" << endl;
            return ss.str();
        };
    };

    class OPENAPI_EXPORT KlineItem {
    public:
        double open = 0;
        double high = 0;
        double low = 0;
        double close = 0;
        time_t time;
        long long volume = 0;
        time_t last_time;
        long long open_interest = 0;
        double settlement = 0;

        void from_json(const web::json::value& j) {
            if (j.has_field(U("open"))) {
                open = j.at(U("open")).as_double();
            }
            if (j.has_field(U("high"))) {
                high = j.at(U("high")).as_double();
            }
            if (j.has_field(U("low"))) {
                low = j.at(U("low")).as_double();
            }
            if (j.has_field(U("close"))) {
                close = j.at(U("close")).as_double();
            }
            if (j.has_field(U("time"))) {
                time = j.at(U("time")).as_number().to_int64();
            }
            if (j.has_field(U("lastTime"))) {
                last_time = j.at(U("lastTime")).as_number().to_int64();
            }
            if (j.has_field(U("volume"))) {
                volume = j.at(U("volume")).as_number().to_int64();
            }
            if (j.has_field(U("settlement"))) {
                settlement = j.at(U("settlement")).as_double();
            }
            if (j.has_field(U("openInterest"))) {
                open_interest = j.at(U("openInterest")).as_number().to_int64();
            }

        }
    };

    class OPENAPI_EXPORT Kline {
    public:
        vector<KlineItem> items;
        utility::string_t symbol;
        utility::string_t contract_code;
        utility::string_t period;
        time_t expiry;
        utility::string_t right;
        utility::string_t strike;

        utility::string_t to_string() {
            return U("Kline of ") + symbol;
        }
    };

    class OPENAPI_EXPORT RealtimeQuote {
    public:
        double open = 0;
        double high = 0;
        double low = 0;
        double close = 0;
        long long volume = 0;
        double adj_pre_close = 0;
        double pre_close = 0;
        double ask_price = 0;
        double ask_size = 0;
        double bid_price = 0;
        double bid_size = 0;
        double latest_price = 0;
        time_t latest_time;
        long long latest_size = 0;
        utility::string_t status;
        utility::string_t symbol;

        utility::string_t contract_code;
        long long open_interest = 0;
        int limit_down = 0;
        int limit_up = 0;


        void from_json(const web::json::value &j) {
            if (j.has_field(U("open")))
                open = j.at(U("open")).as_double();

            if (j.has_field(U("high")))
                high = j.at(U("high")).as_double();

            if (j.has_field(U("low")))
                low = j.at(U("low")).as_double();

            if (j.has_field(U("close")))
                close = j.at(U("close")).as_double();

            if (j.has_field(U("volume")))
                volume = j.at(U("volume")).as_number().to_int64();

            if (j.has_field(U("adjPreClose")))
                adj_pre_close = j.at(U("adjPreClose")).as_double();

            if (j.has_field(U("preClose")))
                pre_close = j.at(U("preClose")).as_double();

            if (j.has_field(U("askPrice")))
                ask_price = j.at(U("askPrice")).as_double();

            if (j.has_field(U("askSize")))
                ask_size = j.at(U("askSize")).as_double();

            if (j.has_field(U("bidPrice")))
                bid_price = j.at(U("bidPrice")).as_double();

            if (j.has_field(U("bidSize")))
                bid_size = j.at(U("bidSize")).as_double();

            if (j.has_field(U("latestPrice")))
                latest_price = j.at(U("latestPrice")).as_double();

            if (j.has_field(U("latestTime")))
                latest_time = j.at(U("latestTime")).as_number().to_int64();

            if (j.has_field(U("latestSize")))
                latest_size = j.at(U("latestSize")).as_number().to_int64();

            if (j.has_field(U("status")))
                status = j.at(U("status")).as_string();

            if (j.has_field(U("symbol")))
                symbol = j.at(U("symbol")).as_string();

            if (j.has_field(U("contractCode")))
                contract_code = j.at(U("contractCode")).as_string();

            if (j.has_field(U("openInterest")))
                open_interest = j.at(U("openInterest")).as_number().to_int64();

            if (j.has_field(U("limitDown")))
                limit_down = j.at(U("limitDown")).as_integer();

            if (j.has_field(U("limitUp")))
                limit_up = j.at(U("limitUp")).as_integer();
        }

        utility::string_t to_string() {
            return U("RealtimeQuote<") + symbol + U("> ");
        }
    };



    class OPENAPI_EXPORT TradeTickItem {
    public:
        std::string tick_type;
        double price;
        int volume;
        std::string part_code;
        std::string part_code_name;
        std::string cond;
        std::string time;
        std::string sn;

    public:
        // Constructor
        TradeTickItem() : 
            price(0), 
            volume(0) 
        {}

        // Getters
        const std::string& get_ticktype() const { return tick_type; }
        double get_price() const { return price; }
        long long get_volume() const { return volume; }
        const std::string& get_partcode() const { return part_code; }
        const std::string& get_partcodename() const { return part_code_name; }
        const std::string& get_cond() const { return cond; }
        const std::string& get_time() const { return time; }
        const std::string& get_sn() const { return sn; }

        // Setters
        void set_ticktype(const std::string& value) { tick_type = value; }
        void set_price(double value) { price = value; }
        void set_volume(long long value) { volume = value; }
        void set_partcode(const std::string& value) { part_code = value; }
        void set_partcodename(const std::string& value) { part_code_name = value; }
        void set_cond(const std::string& value) { cond = value; }
        void set_time(const std::string& value) { time = value; }
        void set_sn(const std::string& value) { sn = value; }

        // toString equivalent
        std::string to_string() const {
            std::ostringstream oss;
            oss << "TradeTickItem<{tick_type: " << tick_type
            << ", price: " << price
            << ", volume: " << volume
            << ", part_code: " << part_code
            << ", part_code_name: " << part_code_name
            << ", cond: " << cond
            << ", time: " << time
            << ", sn: " << sn
            << "}>";
        return oss.str();
        }
    };

    class OPENAPI_EXPORT TradeTick {
    public:
        std::string symbol;
        std::string sec_type;
        std::string quote_level;
        std::string timestamp;
        std::vector<TradeTickItem> ticks;

    public:
        TradeTick() {}

        const std::string& get_symbol() const { return symbol; }
        const std::string& get_sectype() const { return sec_type; }
        const std::string& get_quotelevel() const { return quote_level; }
        const std::string& get_timestamp() const { return timestamp; }
        const std::vector<TradeTickItem>& get_ticks() const { return ticks; }

        void set_symbol(const std::string& value) { symbol = value; }
        void set_sectype(const std::string& value) { sec_type = value; }
        void set_quotelevel(const std::string& value) { quote_level = value; }
        void set_timestamp(const std::string& value) { timestamp = value; }
        void set_ticks(const std::vector<TradeTickItem>& value) { ticks = value; }

        void addTick(const TradeTickItem& tick) {
            ticks.push_back(tick);
        }

        std::string to_string() const {
            std::ostringstream oss;
            oss << "TradeTick<{symbol: " << symbol
            << ", sec_type: " << sec_type
            << ", quote_level: " << quote_level
            << ", timestamp: " << timestamp
            << ", ticks: [";
        
            for (size_t i = 0; i < ticks.size(); ++i) {
                if (i > 0) oss << ", ";
                oss << ticks[i].to_string();
            }
            oss << "]}>";
            return oss.str();
        }
    };


}


#endif //TIGERAPI_MODEL_H
